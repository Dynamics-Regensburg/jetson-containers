#ifndef _VNTIME_H_
#define _VNTIME_H_

#include "vncompiler.h"
#include "vnint.h"
#include "vnerror.h"
#include "vnenum.h"

#if VN_WINDOWS_BASED

	/* Disable some warnings for Visual Studio with -Wall. */
	#if defined(_MSC_VER)
		#pragma warning(push)
		#pragma warning(disable:4668)
		#pragma warning(disable:4820)
		#pragma warning(disable:4255)
	#endif

	#include <Windows.h>

	#if defined(_MSC_VER)
		#pragma warning(pop)
	#endif

#endif

#ifdef __cplusplus
extern "C" {
#endif

/** \brief Provides simple timing capabilities. */
struct VnStopwatch
{
  #if VN_WINDOWS_BASED
  double pcFrequency;
  __int64 counterStart;
  #elif VN_UNIX_BASED
  double clockStart;
  #endif
};

#ifndef __cplusplus
typedef struct VnStopwatch VnStopwatch_t;
#endif

/** \brief Initializes and starts a stopwatch.
 * \param[in] stopwatch The VnStopwatch to initialize and start.
 * \return Any errors encountered. */
enum VnError
VnStopwatch_initializeAndStart(
    struct VnStopwatch *stopwatch);

/** \brief Resets the stopwatch's timing.
 * \param[in] stopwatch The associated VnStopwatch.
 * \return Any errors encountered. */
enum VnError
VnStopwatch_reset(
    struct VnStopwatch *stopwatch);

/** \brief Determines the number of milliseconds elapsed since the last reset
 *      of the stopwatch.
 * \param[in] stopwatch The associated VnStopwatch.
 * \param[out] elapsedMs The elapsed time in milliseconds.
 * \return Any errors encountered. */
enum VnError
VnStopwatch_elapsedMs(
    struct VnStopwatch *stopwatch,
    float *elapsedMs);

#ifdef __cplusplus
}
#endif

#endif
