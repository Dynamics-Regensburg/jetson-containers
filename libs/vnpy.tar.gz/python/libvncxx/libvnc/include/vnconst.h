#ifndef __VNCONTS_H__
#define __VNCONTS_H__

/** Pi in double format. */
#define VNC_PI_D    (3.141592653589793238)

#endif
