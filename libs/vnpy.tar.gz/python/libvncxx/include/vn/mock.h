#ifndef _VNSENSORS_MOCK_H_
#define _VNSENSORS_MOCK_H_

namespace xplat {
namespace sensors {

}
}

#endif
